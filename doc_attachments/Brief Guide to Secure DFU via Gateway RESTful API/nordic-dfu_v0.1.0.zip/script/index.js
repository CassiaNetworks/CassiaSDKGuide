const fs = require('fs');
const co = require('co');
const _ = require('lodash');

const EventSource = require('eventsource');
const request = require('superagent');
const { Command } = require('commander');
const { crc32 } = require('crc');

const program = new Command();

let options = null;

const dfuCharsUuid = {
  dfuControlPoint: '8EC90001-F315-4F60-9FB8-838830DAEA50',
  dfuPacket: '8EC90002-F315-4F60-9FB8-838830DAEA50',
};

const dfuCharsHandle = {
  [dfuCharsUuid.dfuControlPoint]: '',
  [dfuCharsUuid.dfuPacket]: '',
};

let queue = {};

function queueEnd(reqTypeHex, data, err) {
  console.log('[QUEUE] async call end:', reqTypeHex, data || '', err || '');
  if (!queue[reqTypeHex]) return;
  if (err) queue[reqTypeHex].reject(err);
  else queue[reqTypeHex].resolve(data);
  clearTimeout(queue[reqTypeHex].timeout);
  delete queue[reqTypeHex];
}

function queueAdd(reqTypeHex, timeout, fn) {
  console.log('[QUEUE] async call add:', reqTypeHex, timeout);
  return new Promise((resolve, reject) => {
    queue[reqTypeHex] = {
      resolve: resolve,
      reject: reject,
      timeout: setTimeout(function () {
        console.log('[QUEUE] async call wait timeout:', reqTypeHex, timeout);
        queueEnd(reqTypeHex, null, 'timeout');
      }, timeout || 60000)
    };
    fn && fn();
  });
}

const apiReqTimeout = {
  response: 20 * 1000, // wait for first packet time
  deadline: 20 * 1000 // the whole response time
};

function apiConnect() {
  const url = `http://${options.gatewayIp}/gap/nodes/${options.deviceMac}/connection/`;
  console.log('[API] gateway connect start:', url);
  return request.post(url).retry(3).timeout(apiReqTimeout).send({
    discovergatt: 0,
    type: options.deviceAddrType,
    timeout: 15000
  }).then(res => {
    console.log('[API] gateway connect ok:', res.text);
    return res.text;
  });
};

function apiGetAllServices() {
  const url = `http://${options.gatewayIp}/gatt/nodes/${options.deviceMac}/services/characteristics/descriptors`;
  console.log('[API] gateway get all services start:', url);
  return request.get(url).timeout(apiReqTimeout).then(res => {
    console.log('[API] gateway get all services ok:', res.text);
    return JSON.parse(res.text);
  });
}

function apiWrite(handle, value, waitResp = true) {
  console.log('[API] gateway write handle start:', handle, value, waitResp);
  let url = `http://${options.gatewayIp}/gatt/nodes/${options.deviceMac}/handle/${handle}/value/${value}?`;
  if (!waitResp) url += 'noresponse=1';
  return request.get(url).timeout(apiReqTimeout).then(res => {
    console.log('[API] gateway write handle ok:', res.text);
    return res.text;
  });
}

function apiDisconnect() {
  const url = `http://${options.gatewayIp}/gap/nodes/${options.deviceMac}/connection/`;
  console.log('[API] gateway disconnect start:', url);
  return request.delete(url).timeout(apiReqTimeout).then(res => {
    console.log('[API] gateway disconnect ok:', res.text);
    return res.text;
  });
}

function apiNotifySse(msgHandler, errHandler) {
  let url = `http://${options.gatewayIp}/gatt/nodes?event=1`;
  console.log('[API] gateway open notify sse:', url);
  sse = new EventSource(url);
  sse.onerror = errHandler || defaultSseErrHandler;
  sse.onmessage = msgHandler || defaultSseMsgHandler;
  return sse;
}

function getDfuHandles(allServices) {
  for (let idxService = 0; idxService < allServices.length; idxService++) {
    let service = allServices[idxService];
    let characteristics = service.characteristics || [];
    for (let idxChar = 0; idxChar < characteristics.length; idxChar++) {
      let char = characteristics[idxChar];
      let uuid = char.uuid.toUpperCase();
      if (_.has(dfuCharsHandle, uuid)) {
        console.log('[DFU] dfu handle found, uuid:', uuid, 'handle:', char.handle);
        dfuCharsHandle[uuid] = char.handle;
      }
    }
  }
}

function isDfuHandlesOk() {
  console.log('[DFU] check dfu handles:', JSON.stringify(dfuCharsHandle));
  for (let key in dfuCharsHandle) {
    if (!dfuCharsHandle[key]) {
      console.log('[DFU] dfu handle not found, uuid:', key);
      return false;
    }
  }
  return true;
}

// https://infocenter.nordicsemi.com/index.jsp?topic=%2Fsdk_nrf5_v17.1.0%2Flib_dfu_transport.html
const dfuReqTypesHex = {
  Create: '01',
  SetReceiptNotification: '02',
  CRC: '03',
  Execute: '04',

  Select: '06',
  MTUGet: '07',

  Abort: '0C',
};

const dfuResErrCode = {
  Success: 0x01,
  NotSupported: 0x02,

  // TODO: add more
};

// nrf_dfu_obj_type_t
const dfuObjTypes = {
  Command: '01', // NRF_DFU_OBJ_TYPE_COMMAND 
  Data: '02', // NRF_DFU_OBJ_TYPE_DATA 
};

const dfuStages = {
  dat: 'dat',
  bin: 'bin',
};

let todoStage = dfuStages.dat;

function dfuSelect(objTypeHex) {
  return co(function* () {
    console.log('[DFU] start select');
    let reqTypeHex = dfuReqTypesHex.Select;
    let resDataBuf = yield queueAdd(reqTypeHex, 5000, () => co(function* () {
      let reqDataHex = `${dfuReqTypesHex.Select}${objTypeHex}`; // 0601
      yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuControlPoint], reqDataHex);
    }));
    console.log('[DFU] select resp:', resDataBuf);

    if (resDataBuf[0] !== dfuResErrCode.Success) {
      console.log('[DFU] select failed:', resDataBuf);
      throw errCodes.DFU_FAILED;
    }
    let resData = {
      maxSize: resDataBuf.readUInt32LE(1),
      offset: resDataBuf.readUInt32LE(5),
      crc32: resDataBuf.readUInt32LE(9),
    };
    console.log('[DFU] select ok:', resData);
    return resData;
  });
}

function dfuAbort() {
  return co(function* () {
    yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuControlPoint], dfuReqTypesHex.Abort);
  });
}

function dfuMtuGet() {
  return co(function* () {
    console.log('[DFU] start mtu');
    let reqTypeHex = dfuReqTypesHex.MTUGet;
    let resDataBuf = yield queueAdd(reqTypeHex, 5000, () => co(function* () {
      yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuControlPoint], reqTypeHex);
    }));
    console.log('[DFU] mtu resp:', resDataBuf);

    if (resDataBuf[0] !== dfuResErrCode.Success) {
      console.log('[DFU] mtu failed:', resDataBuf);
      throw errCodes.DFU_FAILED;
    }
    console.log('[DFU] mtu ok:', resDataBuf);
  });
}

function dfuSetReceiptNotification() {
  return co(function* () {
    console.log('[DFU] start set receipt notification');
    let reqTypeHex = dfuReqTypesHex.SetReceiptNotification;
    let resDataBuf = yield queueAdd(reqTypeHex, 5000, () => co(function* () {
      let reqDataHex = `${dfuReqTypesHex.SetReceiptNotification}0000`; // 020000
      yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuControlPoint], reqDataHex);
    }));
    console.log('[DFU] set receipt notification resp:', resDataBuf);

    // check Set receipt notification resp
    if (resDataBuf[0] !== dfuResErrCode.Success) {
      console.log('[DFU] Set receipt notification failed:', resDataBuf);
      throw errCodes.DFU_FAILED;
    }
    console.log('[DFU] Set receipt notification ok:', resDataBuf);
  });
}

function dfuCreate(fileSizeHex, objTypeHex) {
  return co(function* () {
    console.log('[DFU] start create command');
    let reqTypeHex = dfuReqTypesHex.Create;
    let resDataBuf = yield queueAdd(reqTypeHex, 5000, () => co(function* () {
      let reqDataHex = `${dfuReqTypesHex.Create}${objTypeHex}${fileSizeHex}`; // 0101${fileSizeHex}
      yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuControlPoint], reqDataHex);
    }));
    console.log('[DFU] create command resp:', resDataBuf);

    if (resDataBuf[0] !== dfuResErrCode.Success) {
      console.log('[DFU] create command failed:', resDataBuf);
      throw errCodes.DFU_FAILED;
    }
    console.log('[DFU] create command ok:', resDataBuf);
  });
}

function dfuSendFileData(datFileContentBuf) {
  return co(function* () {
    console.log('[DFU] start send file data');
    for (let index = 0; index < datFileContentBuf.length; index += options.packetSize) {
      let packetBuf = datFileContentBuf.slice(index, index + options.packetSize);
      let packetHex = packetBuf.toString('hex');
      yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuPacket], packetHex, false);
    }
    console.log('[DFU] send file data ok');
  });
}

function dfuCrc() {
  return co(function* () {
    console.log('[DFU] start crc');
    let reqTypeHex = dfuReqTypesHex.CRC;
    let resDataBuf = yield queueAdd(reqTypeHex, 5000, () => co(function* () {
      let reqDataHex = reqTypeHex;
      yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuControlPoint], reqDataHex); // 03
    }));
    console.log('[DFU] crc resp:', resDataBuf);

    if (resDataBuf[0] !== dfuResErrCode.Success) {
      console.log('[DFU] crc failed:', resDataBuf);
      throw errCodes.DFU_FAILED;
    }

    let resData = {
      offset: resDataBuf.readUInt32LE(1),
      crc32: resDataBuf.readUInt32LE(5),
    };
    console.log('[DFU] crc ok:', resData);
    return resData;
  });
}

function dfuExecute() {
  return co(function* () {
    console.log('[DFU] start execute');
    let reqTypeHex = dfuReqTypesHex.Execute;
    let resDataBuf = yield queueAdd(reqTypeHex, 5000, () => co(function* () {
      let reqDataHex = reqTypeHex;
      yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuControlPoint], reqDataHex); // 04
    }));
    console.log('[DFU] execute resp:', resDataBuf);

    if (resDataBuf[0] !== dfuResErrCode.Success) {
      console.log('[DFU] execute failed:', resDataBuf);
      throw errCodes.DFU_FAILED;
    }
    console.log('[DFU] execute ok:', resDataBuf);
  });
}

function execDfuStageDat() {
  return co(function* () {
    console.log('[DFU] start dfu stage:', todoStage);

    console.log('---------------------------');
    let resData = yield dfuSelect(dfuObjTypes.Command);
    if (resData.offset !== 0) {
      console.log('[DFU] select failed, offset not 0, do not transfer anything and skip to Execute command:', resData);
      yield dfuExecute();
      return;
    }

    console.log('---------------------------');
    yield dfuSetReceiptNotification();

    // read dat file size
    let fileSize = fs.statSync(options.datFilePath).size;
    let fileSizeBuf = Buffer.alloc(4);
    fileSizeBuf.writeUInt32LE(fileSize, 0);
    let fileSizeHex = fileSizeBuf.toString('hex');

    console.log('---------------------------');
    yield dfuCreate(fileSizeHex, dfuObjTypes.Command);

    let fileContentBuf = fs.readFileSync(options.datFilePath).slice(0, fileSize);
    console.log('---------------------------');
    yield dfuSendFileData(fileContentBuf);

    console.log('---------------------------');
    resData = yield dfuCrc();
    let calcCrc32 = crc32(fileContentBuf);
    console.log('[DFU] crc32 check:', { retCrc32: resData.crc32, calcCrc32 });
    if (options.crcCheck && resData.crc32 !== calcCrc32) {
      console.log('[DFU] crc32 check failed, please retry');
      // TODO: crc32 check failed, what to do?
      throw errCodes.DFU_FAILED;
    }

    console.log('---------------------------');
    yield dfuExecute();

    console.log('[DFU] dfu stage ok:', todoStage);
  });
}

function execDfuStageBin() {
  return co(function* () {
    console.log('[DFU] start dfu stage:', todoStage);

    console.log('---------------------------');
    let resData = yield dfuSelect(dfuObjTypes.Data);
    if (resData.offset !== 0) {
      console.log('[DFU] select failed, offset not 0, do not transfer anything and skip to Execute command:', resData);
      yield dfuExecute();
      return;
    }

    console.log('---------------------------');
    yield dfuSetReceiptNotification();

    // read dat file size
    let fileSize = fs.statSync(options.binFilePath).size;
    let fileSizeBuf = Buffer.alloc(4);
    fileSizeBuf.writeUInt32LE(fileSize, 0);
    let fileSizeHex = fileSizeBuf.toString('hex');

    console.log('---------------------------');
    yield dfuCreate(fileSizeHex, dfuObjTypes.Data);

    let fileContentBuf = fs.readFileSync(options.binFilePath).slice(0, fileSize);
    console.log('---------------------------');
    yield dfuSendFileData(fileContentBuf);

    console.log('---------------------------');
    resData = yield dfuCrc();
    let calcCrc32 = crc32(fileContentBuf);
    console.log('[DFU] crc32 check:', { retCrc32: resData.crc32, calcCrc32 });
    if (options.crcCheck && resData.crc32 !== calcCrc32) {
      console.log('[DFU] crc32 check failed, please retry');
      // TODO: crc32 check failed, what to do?
      throw errCodes.DFU_FAILED;
    }

    console.log('---------------------------');
    yield dfuExecute();

    console.log('[DFU] dfu stage ok:', todoStage);
  });
}


function dfu() {
  return co(function* () {
    // connect device
    yield apiConnect();

    // get all services
    let allServices = yield apiGetAllServices();

    // get dfu handles
    getDfuHandles(allServices);
    let isFound = isDfuHandlesOk();
    if (!isFound) throw '[DFU] no dfu all handles found';

    // open dfu packet notification
    yield apiWrite(dfuCharsHandle[dfuCharsUuid.dfuControlPoint] + 1, '0100');

    // query preferred MTU size
    // yield dfuMtuGet();

    // dfu dat file
    todoStage = dfuStages.dat;
    yield execDfuStageDat();

    hasWriteDatFile = true;

    // dfu bin file
    todoStage = dfuStages.bin;
    yield execDfuStageBin();

    // disconnect device
    yield apiDisconnect();

    console.log('[DFU] dfu ok:', options.deviceMac);
  }).catch((err) => {
    console.log('[DFU] dfu err:', options.deviceMac, _.get(err, 'response.text', ''), err);
    apiDisconnect().then(() => {
      console.log('[DFU] disconnect ok');
      throw errCodes.DFU_FAILED;
    }).catch(ex => {
      console.log('[DFU] disconnect error:', ex);
      throw errCodes.DFU_FAILED;
    });
  });
}

function msgHandler(msg) {
  console.log('[API] notify data:', msg.data);
  let data = JSON.parse(msg.data);
  let handle = data.handle;
  if (handle !== dfuCharsHandle[dfuCharsUuid.dfuControlPoint]) {
    console.log('[API] notify data not dfu control point');
    return;
  }

  let value = data.value;
  let valueBuf = Buffer.from(value, 'hex');
  if (valueBuf[0] !== 0x60 || valueBuf.length < 2) {
    console.log('[API] not resp data, ignore it');
    return;
  }

  let reqTypeHex = valueBuf.slice(1, 2).toString('hex');
  queueEnd(reqTypeHex, valueBuf.slice(2)); // return resp data
}

function errHandler(err) {
  console.log('[API] notify sse error:', err);
}

function execDeviceDfu() {
  apiNotifySse(msgHandler, errHandler);
  return dfu();
}

function parseOptions(opts) {
  // Check if IP address is valid
  if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(opts.gatewayIp)) {
    console.error('Invalid IP address');
    throw errCodes.INVALID_PARAMS;
  }

  // Check if file paths exist
  if (!fs.existsSync(opts.datFilePath)) {
    console.error('DFU dat file does not exist');
    throw errCodes.INVALID_PARAMS;
  }

  if (!fs.existsSync(opts.binFilePath)) {
    console.error('DFU bin file does not exist');
    throw errCodes.INVALID_PARAMS;
  }

  options = opts;
  console.log('[MAIN] options:', JSON.stringify(options));
}

const errCodes = {
  SUCCESS: 0,
  INVALID_PARAMS: 1,
  DFU_FAILED: 2,
}

function main(opts) {
  return co(function* () {
    parseOptions(opts);
    yield execDeviceDfu();
    process.exit(errCodes.SUCCESS);
  }).catch(ex => {
    console.log('execDeviceDfu error:', ex);
    setTimeout(() => {
      process.exit(ex);
    }, 3000);
  });
}

program
  .name('nordic-dfu')
  .version('0.1.0')
  .helpOption('-h, --help', 'Display help for command')
  .description('Perform DFU (Device Firmware Update) on BLE devices using the Nordic SDK through the gateway\'s RESTful API.')
  .requiredOption('-g, --gateway-ip <ip>', 'Gateway IP address')
  .requiredOption('-m, --device-mac <mac>', 'Device MAC address')
  .option('-t, --device-addr-type <type>', 'Device address type, supports "public" and "random". Default is "random"', 'random')
  .requiredOption('-d, --dat-file-path <path>', 'DFU dat file path')
  .requiredOption('-b, --bin-file-path <path>', 'DFU bin file path')
  .requiredOption('-p, --packet-size <size>', 'Packet size for each write operation, recommended packet size is either 244 or 20 bytes', parseInt)
  .option('-c, --crc-check <boolean>', 'Enable CRC32 check, default is true', true)
  .action(main);

program.parse(process.argv);

